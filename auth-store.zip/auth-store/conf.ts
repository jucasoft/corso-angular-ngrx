export const afterLoginUri = 'home';
export const afterLogoutUri = 'home';
