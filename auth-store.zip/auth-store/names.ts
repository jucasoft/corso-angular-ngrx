export class Names {
  static NAME = 'auth';
}
